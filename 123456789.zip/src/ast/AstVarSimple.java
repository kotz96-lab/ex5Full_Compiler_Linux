package ast;

import ir.Ir;
import ir.IrCommandLoad;
import ir.IrCommandFieldAccess;
import temp.Temp;
import temp.TempFactory;
import types.*;
import symboltable.*;

public class AstVarSimple extends AstVar
{
	/************************/
	/* simple variable name */
	/************************/
	public String name;
	public int offset = -1;
	public boolean isFieldAccess = false;  // True if this is actually a field access through 'this'
	public int fieldOffset = -1;  // Offset of field in object

	/******************/
	/* CONSTRUCTOR(S) */
	/******************/
	public AstVarSimple(String name, int line)
	{
		/******************************/
		/* SET A UNIQUE SERIAL NUMBER */
		/******************************/
		serialNumber = AstNodeSerialNumber.getFresh();
	
		/***************************************/
		/* PRINT CORRESPONDING DERIVATION RULE */
		/***************************************/
		System.out.format("====================== var -> ID( %s )\n",name);

		/*******************************/
		/* COPY INPUT DATA MEMBERS ... */
		/*******************************/
		this.name = name;
		this.line = line;
	}

	/**************************************************/
	/* The printing message for a simple var AST node */
	/**************************************************/
	public void printMe()
	{
		/**********************************/
		/* AST NODE TYPE = AST SIMPLE VAR */
		/**********************************/
		System.out.format("AST NODE SIMPLE VAR( %s )\n",name);

		/**********************************/
		/* Print to AST GRAPHVIZ DOT file */
		/**********************************/
		AstGraphviz.getInstance().logNode(
				serialNumber,
			String.format("SIMPLE\nVAR\n(%s)",name));
	}

	public Type semantMe() throws SemanticException
	{
        SymbolTableEntry entry = SymbolTable.getInstance().findEntry(name);
		if (entry == null)
		{
			throw new SemanticException(line, String.format("variable %s not found", name));
		}

        this.offset = entry.prevtopIndex; // Store the offset for later IR generation

		// Check if this is a field access (when TypeField is present)
		if (entry.type instanceof TypeField)
		{
			isFieldAccess = true;
			// Calculate field offset if we're in a class method
			if (AstTypeName.currentClass != null)
			{
				fieldOffset = AstTypeName.currentClass.getFieldOffset(name);
			}
			return ((TypeField) entry.type).fieldType;
		}
		return entry.type;
	}

    public Temp irMe()
    {
        Temp t = TempFactory.getInstance().getFreshTemp();

        // Check if we're in a method and this variable is actually a field
        if (AstTypeName.currentClass != null)
        {
            // Try to find this name as a field in the current class
            Type fieldType = AstTypeName.currentClass.find(name);
            if (fieldType != null)
            {
                // This is a field access! Generate field access through 'this'
                SymbolTableEntry thisEntry = SymbolTable.getInstance().findEntry("this");
                if (thisEntry != null)
                {
                    int actualFieldOffset = AstTypeName.currentClass.getFieldOffset(name);

                    String thisVarName = String.format("this_%d", thisEntry.prevtopIndex);
                    Temp thisTemp = TempFactory.getInstance().getFreshTemp();
                    Ir.getInstance().AddIrCommand(new IrCommandLoad(thisTemp, thisVarName));

                    // Generate field access
                    Ir.getInstance().AddIrCommand(new IrCommandFieldAccess(t, thisTemp, actualFieldOffset, name));
                    return t;
                }
            }
        }

        /*******************************************************/
        /* Regular variable access                             */
        /*******************************************************/
        String varNameWithOffset = String.format("%s_%d", name, offset);
        Ir.getInstance().AddIrCommand(new IrCommandLoad(t, varNameWithOffset));
        return t;
    }
}
