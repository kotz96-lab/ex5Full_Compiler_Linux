#!/bin/bash
# Test recursive functions
TESTS="TEST_01_Print_Primes TEST_12_Fib TEST_19 TEST_22"

for test_file in $TESTS; do
    test_path="self-check-ex5/tests/${test_file}.txt"
    output_file="test_${test_file}.s"
    
    if [ ! -f "$test_path" ]; then
        continue
    fi
    
    echo -n "Testing $test_file (recursive) ... "
    
    # Compile
    java -jar COMPILER "$test_path" "$output_file" 2>&1 | grep -q "SUCCESS"
    if [ $? -ne 0 ]; then
        echo "❌ COMPILE FAIL"
        continue
    fi
    
    # Run with short timeout (recursion will likely hang)
    timeout 2 spim -file "$output_file" >/dev/null 2>&1
    exitcode=$?
    
    if [ $exitcode -eq 124 ]; then
        echo "⏱️  TIMEOUT (recursion issue)"
    elif [ $exitcode -eq 0 ]; then
        echo "✅ COMPLETED"
    else
        echo "❌ ERROR (exit $exitcode)"
    fi
done
