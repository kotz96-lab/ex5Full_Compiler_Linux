# Testing & Next Steps - Exercise 5 Complete Compiler

## ✅ What's Been Done

### 1. Complete Implementation (All 3 Persons)
- ✅ **Person A**: IR Generation (22 files) - `ex5persona/src/ir/` and `ex5persona/src/ast/`
- ✅ **Person B**: Register Allocation (7 files) - `ex5persona/src/regalloc/`
- ✅ **Person C**: MIPS Generation (5 files) - `ex5persona/src/mips/`

### 2. Integration
- ✅ All code unified in `ex5persona/` directory
- ✅ Main.java updated to run full pipeline: AST → IR → RegAlloc → MIPS
- ✅ Ir.java updated with `getCommands()` method

### 3. Build Infrastructure
- ✅ Makefile (for Linux/Mac)
- ✅ build.bat (for Windows)
- ✅ All dependencies copied (jflex, cup, external_jars, manifest)

### 4. Documentation
- ✅ WINDOWS_BUILD_GUIDE.md - Complete build & test guide
- ✅ COMPLETE_COMPILER.md - Technical overview
- ✅ FINAL_PROJECT_SUMMARY.md - Project summary
- ✅ PERSON_A/B/C_COMPLETE.md - Individual component docs

## 📋 What You Need To Do Now

### Step 1: Build the Compiler

**On Windows:**
```batch
cd c:\Users\kotz9\OneDrive\Desktop\school\current\compliation\hw\ex5persona
build.bat
```

This should create `COMPILER` (JAR file).

**Expected output:**
```
====================================
 Exercise 5 - L Compiler Build
====================================

[0] Removing old COMPILER.jar...
[1] Cleaning old .class files...
[2] Generating Lexer.java with JFlex...
[3] Generating Parser.java and TokenNames.java with CUP...
[4] Compiling Java files...
[5] Creating COMPILER.jar...

====================================
 Build Complete!
====================================

COMPILER.jar created successfully.
```

### Step 2: Test on Simple Program

```batch
java -jar COMPILER input\Input.txt output\Output.s
```

**Expected output:**
```
[Person A] IR Generation: X commands
[Person B] Register Allocation: SUCCESS
[Person C] MIPS Generation: SUCCESS
Compilation complete: output\Output.s
```

**Check the output file:**
```batch
type output\Output.s
```

Should see MIPS assembly code with:
- `.data` section (error messages)
- `.text` section (main code)
- Error handlers at the end

### Step 3: Test on Self-Check Tests (Manual)

Since the self-check script expects Linux, you'll need to test manually:

```batch
REM Test 1: Simple function (TEST_18)
java -jar COMPILER ..\self-check-ex5\tests\TEST_18.txt test18.s
type test18.s

REM Test 2: Overflow (TEST_13)
java -jar COMPILER ..\self-check-ex5\tests\TEST_13_Overflow.txt test13.s
type test13.s

REM Test 3: Register allocation failure (TEST_26)
java -jar COMPILER ..\self-check-ex5\tests\TEST_26.txt test26.txt
type test26.txt
REM Should show: "Register Allocation Failed"
```

### Step 4: Run MIPS in Simulator (Optional)

If you have SPIM installed:
```batch
spim -file output\Output.s
```

Or use QtSpim (GUI) to load and run the .s files.

## 🐛 Potential Issues & Fixes

### Issue 1: JFlex not found
**Symptom:** "jflex is not recognized as an internal or external command"

**Fix Options:**
1. Install JFlex and add to PATH
2. Or download jflex.jar and modify build.bat to use:
   ```batch
   java -jar path\to\jflex.jar -d src jflex\LEX_FILE.lex
   ```

### Issue 2: Compilation errors
**Symptom:** javac errors during build

**Check:**
1. All packages present in src/ directory
2. Ir.java has getCommands() method
3. Main.java imports are correct

**Fix:** Check the specific error message and look for missing files or methods

### Issue 3: Runtime exceptions
**Symptom:** Compiler crashes with NullPointerException or similar

**Common Causes:**
1. AST node missing irMe() implementation
2. IR command not handled in Register Allocator
3. IR command not handled in MIPS Translator

**Debug:**
- Check which IR command caused the crash
- Verify it's implemented in all three phases

### Issue 4: Wrong MIPS output
**Symptom:** MIPS file generated but doesn't run correctly

**Check:**
1. Does it have all sections (.data, .text, error handlers)?
2. Does register allocation show SUCCESS?
3. Are registers properly allocated ($t0-$t9)?

### Issue 5: Semantic errors on valid L programs
**Symptom:** Compilation fails with "Semantic Error"

**Fix:** This might be from ex4 semantic analysis. Check if the test program is actually valid L code.

## 🔍 Debugging Tips

### Enable Verbose Output

Add debug prints to Main.java:

```java
// After IR generation
System.out.println("IR Commands:");
for (IrCommand cmd : commands) {
    System.out.println("  " + cmd);
}

// After register allocation
System.out.println("Register Mapping:");
for (Temp t : allocation.getAllTemps()) {
    System.out.println("  " + t + " -> " + allocation.getRegister(t));
}
```

### Check Intermediate Steps

```batch
REM Just parse and generate IR (comment out steps 4-5 in Main.java)
java -jar COMPILER input\test.txt output\dummy.txt

REM Should print IR to console
```

### Test Individual Components

Create small test programs for each feature:

**Test Person A (IR Generation):**
- Integers: `int x := 5;`
- Strings: `string s := "hello";`
- Arrays: `int[] arr := new int[10];`

**Test Person B (Register Allocation):**
- Few variables (should succeed)
- Many variables (might fail if > 10 live at once)

**Test Person C (MIPS Generation):**
- Check saturation: `int x := 32767 + 1;`
- Check runtime checks: `int x := 5 / 0;`

## 📊 Test Coverage Checklist

### Basic Features
- [ ] Integer constants
- [ ] Integer arithmetic (+, -, *, /)
- [ ] Integer comparisons (=, <, >)
- [ ] Saturation arithmetic
- [ ] Unary negation

### Strings
- [ ] String literals
- [ ] String concatenation
- [ ] String equality

### Arrays
- [ ] Array allocation
- [ ] Array access
- [ ] Array store
- [ ] Array length
- [ ] Bounds checking

### Objects (if tested)
- [ ] Object allocation
- [ ] Field access
- [ ] Field store
- [ ] Method calls

### Control Flow
- [ ] If statements
- [ ] While loops
- [ ] Function calls
- [ ] Return statements

### Runtime Checks
- [ ] Division by zero
- [ ] Null pointer dereference
- [ ] Array bounds violation

### Register Allocation
- [ ] Simple programs (few variables)
- [ ] Complex programs (many variables)
- [ ] Register allocation failure (TEST_26)

## 🎯 Success Criteria

### Minimum (to verify it works):
1. ✅ Compiler builds successfully
2. ✅ TEST_18 compiles and produces MIPS
3. ✅ TEST_13 (overflow) produces correct saturation
4. ✅ TEST_26 produces "Register Allocation Failed"

### Full Success (all tests pass):
1. ✅ All 26 self-check tests compile
2. ✅ MIPS output matches expected output structure
3. ✅ SPIM can run generated MIPS code
4. ✅ Program output matches expected values

## 📝 Known Limitations

### Things That Might Not Be Fully Implemented:

1. **Function Arguments**: Passing arguments on stack might be simplified
2. **Global Variables**: Initialization might be incomplete
3. **Method Dispatch**: Vtables for dynamic dispatch might be simplified
4. **String Operations**: Full string library might be basic

### Things That Are Definitely Implemented:

1. ✅ Full IR generation for all L constructs
2. ✅ Complete liveness analysis
3. ✅ Graph coloring register allocation
4. ✅ Saturation arithmetic
5. ✅ Runtime safety checks
6. ✅ Basic MIPS generation for all IR commands

## 🚀 After Testing

### If Tests Pass:
1. Copy successful setup to submission directory
2. Update any documentation
3. Create submission zip

### If Tests Fail:
1. Note which tests fail
2. Check error messages
3. Debug specific issues
4. Update code in ex5persona
5. **Remember**: Also update Person A code in ex5persona if you fix bugs there!

## 📞 Getting Help

### Check Documentation:
1. WINDOWS_BUILD_GUIDE.md - Build instructions
2. COMPLETE_COMPILER.md - Technical details
3. PERSON_A/B/C_COMPLETE.md - Component-specific docs

### Debug Strategy:
1. Start with simplest test (TEST_18)
2. Add debug prints to Main.java
3. Check each phase output (IR, RegAlloc, MIPS)
4. Test incrementally (fix one issue at a time)

---

## 🎉 Ready to Start!

Everything is set up and ready for testing. The main directory is:

**`c:\Users\kotz9\OneDrive\Desktop\school\current\compliation\hw\ex5persona`**

Just run `build.bat` and you're good to go!

Good luck! 🍀
