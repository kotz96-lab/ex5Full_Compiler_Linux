package ast;

import ir.Ir;
import ir.IrCommandLoad;
import ir.IrCommandFieldAccess;
import temp.Temp;
import temp.TempFactory;
import types.*;
import symboltable.*;

public class AstVarSimple extends AstVar
{
	/************************/
	/* simple variable name */
	/************************/
	public String name;
	public int offset = -1;
	public boolean isFieldAccess = false;  // True if this is actually a field access through 'this'
	public int fieldOffset = -1;  // Offset of field in object
	private String cachedThisVarName = null;  // Cached "this" var name for IR generation

	/******************/
	/* CONSTRUCTOR(S) */
	/******************/
	public AstVarSimple(String name, int line)
	{
		/******************************/
		/* SET A UNIQUE SERIAL NUMBER */
		/******************************/
		serialNumber = AstNodeSerialNumber.getFresh();
	
		/***************************************/
		/* PRINT CORRESPONDING DERIVATION RULE */
		/***************************************/
		System.out.format("====================== var -> ID( %s )\n",name);

		/*******************************/
		/* COPY INPUT DATA MEMBERS ... */
		/*******************************/
		this.name = name;
		this.line = line;
	}

	/**************************************************/
	/* The printing message for a simple var AST node */
	/**************************************************/
	public void printMe()
	{
		/**********************************/
		/* AST NODE TYPE = AST SIMPLE VAR */
		/**********************************/
		System.out.format("AST NODE SIMPLE VAR( %s )\n",name);

		/**********************************/
		/* Print to AST GRAPHVIZ DOT file */
		/**********************************/
		AstGraphviz.getInstance().logNode(
				serialNumber,
			String.format("SIMPLE\nVAR\n(%s)",name));
	}

	public Type semantMe() throws SemanticException
	{
        SymbolTableEntry entry = SymbolTable.getInstance().findEntry(name);
		if (entry == null)
		{
			throw new SemanticException(line, String.format("variable %s not found", name));
		}

        this.offset = entry.prevtopIndex; // Store the offset for later IR generation

		// DEBUG
		if (name.equals("grades"))
		{
			System.err.println("DEBUG grades: type=" + entry.type.getClass().getSimpleName() +
				", isTypeField=" + (entry.type instanceof TypeField));
			SymbolTableEntry thisTest = SymbolTable.getInstance().findEntry("this");
			System.err.println("DEBUG grades: thisExists=" + (thisTest != null) +
				", thisType=" + (thisTest != null ? thisTest.type.getClass().getSimpleName() : "null"));
		}


		// Check if we're in a class method (by checking if 'this' exists)
		SymbolTableEntry thisEntry = SymbolTable.getInstance().findEntry("this");
		if (thisEntry != null && thisEntry.type instanceof TypeClass)
		{
			// We're in a class method!
			TypeClass currentClass = (TypeClass) thisEntry.type;

			// Try to look up this variable in the class fields
			// Search through all data members including inherited ones
			TypeClass searchClass = currentClass;
			while (searchClass != null)
			{
			if (searchClass.dataMembers != null)
			{
				for (TypeList it = searchClass.dataMembers; it != null; it = it.tail)
				{
					if (it.head != null && it.head.name != null && it.head.name.equals(name))
					{
						// Found it! This is a field
						isFieldAccess = true;
						fieldOffset = currentClass.getFieldOffset(name);
						cachedThisVarName = String.format("this_%d", thisEntry.prevtopIndex);
						// Return the actual field type (unwrap TypeField if present)
						if (it.head instanceof TypeField)
						{
							return ((TypeField) it.head).fieldType;
							}
							return it.head;
						}
					}
				}
				searchClass = searchClass.father;
			}
		}

		// Check if this is a field access (when TypeField is present) - legacy check
		if (entry.type instanceof TypeField)
		{
			isFieldAccess = true;
			// Calculate field offset - try 'this' first, then currentClass
			SymbolTableEntry thisEntry2 = SymbolTable.getInstance().findEntry("this");
			if (thisEntry2 != null && thisEntry2.type instanceof TypeClass)
			{
				fieldOffset = ((TypeClass) thisEntry2.type).getFieldOffset(name);
				cachedThisVarName = String.format("this_%d", thisEntry2.prevtopIndex);
			}
			else if (AstTypeName.currentClass != null)
			{
				fieldOffset = AstTypeName.currentClass.getFieldOffset(name);
			}
			return ((TypeField) entry.type).fieldType;
		}
		return entry.type;
	}

	public Temp irMe()
    {
        Temp t = TempFactory.getInstance().getFreshTemp();

		// DEBUG
		if (name.equals("grades"))
		{
			System.err.println("DEBUG grades irMe: isFieldAccess=" + isFieldAccess +
				", currentClass=" + (AstTypeName.currentClass != null ? AstTypeName.currentClass.name : "null") +
				", fieldOffset=" + fieldOffset);
		}

        // Check if this was marked as a field access during semantic analysis
        if (isFieldAccess && cachedThisVarName != null)
        {
            // This is a field access! Generate field access through 'this'
            // Use cached fieldOffset from semantic analysis
            int actualFieldOffset = fieldOffset;

            Temp thisTemp = TempFactory.getInstance().getFreshTemp();
            Ir.getInstance().AddIrCommand(new IrCommandLoad(thisTemp, cachedThisVarName));

            // Generate field access
            Ir.getInstance().AddIrCommand(new IrCommandFieldAccess(t, thisTemp, actualFieldOffset, name));
            return t;
        }

        /*******************************************************/
        /* Regular variable access                             */
        /*******************************************************/
        String varNameWithOffset = String.format("%s_%d", name, offset);
        Ir.getInstance().AddIrCommand(new IrCommandLoad(t, varNameWithOffset));
        return t;
    }

	public String getCachedThisVarName()
	{
		return cachedThisVarName;
	}
}
