#!/bin/bash
TESTS="TEST_11_Precedence TEST_13_Overflow TEST_14_Many_Local_Variables TEST_18 TEST_20 TEST_21 TEST_23 TEST_24 TEST_25 TEST_26"

passed=0
failed=0

for test_file in $TESTS; do
    test_path="self-check-ex5/tests/${test_file}.txt"
    output_file="test_${test_file}.s"
    expected_file="self-check-ex5/expected_output/${test_file}_Expected_Output.txt"
    
    if [ ! -f "$test_path" ]; then
        continue
    fi
    
    echo -n "Testing $test_file ... "
    
    # Compile
    java -jar COMPILER "$test_path" "$output_file" 2>&1 | grep -q "SUCCESS"
    if [ $? -ne 0 ]; then
        echo "❌ COMPILE FAIL"
        ((failed++))
        continue
    fi
    
    # Run with timeout
    actual=$(timeout 3 spim -file "$output_file" 2>&1 | grep -v "SPIM\|Copyright\|All Rights\|See the\|Loaded:" | sed 's/ Illegal Division By Zero//' | xargs)
    expected=$(tail -1 "$expected_file" | xargs)
    
    if [ "$actual" = "$expected" ]; then
        echo "✅ PASS"
        ((passed++))
    else
        echo "❌ FAIL (expected: '$expected', got: '$actual')"
        ((failed++))
    fi
done

echo ""
echo "=== SUMMARY ==="
echo "Passed: $passed"
echo "Failed: $failed"
