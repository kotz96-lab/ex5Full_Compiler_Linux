# Parameter Passing Fix - Ex5 Compiler

## Problem
The compiler was generating all zeros in output because function parameters were not being passed correctly. When calling functions like `PrintPrimes(2, 100)` or `IsPrime(p)`, the argument values were not being stored into the parameter variables that the functions expected to read from.

## Root Cause
The IR generation for function calls (in `AstExpCall.irMe()`) was trying to store arguments using parameter TYPE names (like "int") instead of parameter VARIABLE names with serial numbers (like "start_75", "end_73", "p_7").

The parameter variable names are generated during semantic analysis when `AstTypeName` nodes are created, and they include serial numbers to make them unique. However, these names were not being stored anywhere accessible to the caller.

## Solution Architecture

### 1. Extended TypeFunction (3 files modified)
**Files:**
- `ex5/src/types/TypeFunction.java`
- `ex5persona/src/types/TypeFunction.java`

**Changes:**
Added a new field to store parameter variable names:
```java
public List<String> paramVarNames; // e.g., ["p_7", "start_8", "end_9"]
```

### 2. Captured Parameter Names During Semantic Analysis (4 files modified)
**Files:**
- `ex5/src/ast/AstDecFunc.java`
- `ex5persona/src/ast/AstDecFunc.java`
- `ex5/src/ast/AstTypeName.java`
- `ex5persona/src/ast/AstTypeName.java`

**Changes in AstDecFunc.semantMe():**
When entering parameters into the symbol table, we now also store their fully-qualified variable names in the TypeFunction:
```java
for (AstTypeNameList it = params; it != null; it = it.tail) {
    t = SymbolTable.getInstance().find(it.head.type.name);
    SymbolTable.getInstance().enter(it.head.name, t);

    // NEW: Store parameter variable name for IR generation
    String paramVarName = String.format("%s_%d", it.head.name, it.head.serialNumber);
    funcType.paramVarNames.add(paramVarName);
}
```

**Changes in AstTypeName.semantMe():**
Applied the same fix for class method parameters (lines 188-190).

### 3. Updated Function Call IR Generation (2 files modified)
**Files:**
- `ex5/src/ast/AstExpCall.java`
- `ex5persona/src/ast/AstExpCall.java`

**Changes in AstExpCall.irMe():**
Now uses the parameter variable names from TypeFunction instead of parameter type names:
```java
// OLD (wrong):
String paramName = paramList.head.name;  // Gets "int"
Ir.getInstance().AddIrCommand(new ir.IrCommandStore(paramName, argTemp));

// NEW (correct):
String paramVarName = funcType.paramVarNames.get(paramIndex);  // Gets "p_7"
Ir.getInstance().AddIrCommand(new ir.IrCommandStore(paramVarName, argTemp));
```

## Files Modified Summary
- `TypeFunction.java` (ex5 + ex5persona): Added paramVarNames field
- `AstDecFunc.java` (ex5 + ex5persona): Capture param names in semantMe()
- `AstTypeName.java` (ex5 + ex5persona): Capture method param names in semantMe()
- `AstExpCall.java` (ex5 + ex5persona): Use param names from TypeFunction in irMe()

**Total:** 8 files modified

## Example IR Before and After

### Before (WRONG):
```
[ 66] Temp_35 := 100
[ 67] int := Temp_35           # Storing to TYPE name "int"
[ 68] Temp_36 := 2
[ 69] int := Temp_36           # Overwriting same variable!
[ 70] Temp_37 := PrintPrimes()
```

### After (CORRECT):
```
[ 66] Temp_34 := 100
[ 67] start_75 := Temp_34      # Storing to actual parameter variable
[ 68] Temp_35 := 2
[ 69] end_73 := Temp_35        # Storing to second parameter variable
[ 70] Temp_36 := PrintPrimes()
```

## Testing Status
- ✅ Compiles successfully (no errors)
- ✅ Generates valid MIPS assembly
- ✅ Parameter variables correctly declared in .data section
- ✅ Store instructions use correct variable names
- ⏳ Needs SPIM execution test on nova to verify correct output

## Next Steps
1. Upload to nova.cs.tau.ac.il
2. Run self-check-ex5.zip tests
3. Verify that TEST_01_Print_Primes outputs: `2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97`
4. Check all 26 tests for correctness

---
**Date:** 2026-01-17
**Status:** Ready for nova testing
