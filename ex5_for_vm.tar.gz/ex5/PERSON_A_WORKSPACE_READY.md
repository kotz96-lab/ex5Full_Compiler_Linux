# Person A Workspace is Ready! 🎉

## Location
📁 `ex5/person_a_ir_generation/`

## What's Inside

### 📚 Documentation (4 files)
1. **GETTING_STARTED.md** ⭐ - Read this first! Step-by-step guide
2. **WORKSPACE_SUMMARY.md** - Complete overview of workspace and tasks
3. **README.md** - Work plan and current state analysis
4. **TODO_PERSON_A.md** - Detailed checklist with code examples

### 💻 Source Code
- **src/** - All 88 Java files from ex4 copied over
  - 42 AST node classes
  - 18 IR command classes
  - Supporting infrastructure (temp, symboltable, types, cfg)

### 📝 Templates (3 example IR commands)
- **IrCommandStringConcat.java** - String concatenation template
- **IrCommandArrayAccess.java** - Array access template
- **IrCommandNewArray.java** - Array allocation template

## Person A's Mission

**Goal:** Extend IR generation from ex4's limited subset to handle the ENTIRE L language.

**Main tasks:**
1. Create ~14 new IR command types (strings, arrays, objects)
2. Implement/extend ~10 AST irMe() methods
3. Handle evaluation order properly (left-to-right)
4. Test with full L programs

**Estimated effort:** 20-30 hours

## Quick Start for Person A

1. Open `person_a_ir_generation/GETTING_STARTED.md`
2. Read through the existing ex4 code to understand patterns
3. Start creating new IR commands using the templates
4. Implement irMe() methods in AST nodes
5. Test with simple L programs
6. Coordinate with Person B and C for integration

## What Person A Delivers

**To Person B (Register Allocation):**
- Complete IR representation
- List of temporaries
- IR format documentation

**To Person C (MIPS Generation):**
- IR command semantics
- String literal table
- Memory layout specs

## Key Files to Start With

1. Read `src/ir/IrCommand.java` - Understand IR base class
2. Read `src/ir/IrCommandBinopAddIntegers.java` - See example IR command
3. Read `src/ast/AstStmtAssign.java` - See how irMe() works
4. Read `templates/IrCommandStringConcat.java` - Template for new commands

## Status

✅ Workspace created
✅ Source code copied from ex4
✅ Documentation written
✅ Templates provided
🔲 Ready for Person A to start coding!

---

**Next step:** Person A should read `GETTING_STARTED.md` and dive in!
