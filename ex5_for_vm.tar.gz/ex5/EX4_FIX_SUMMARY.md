# Ex4 Semantic Analyzer Fix - TEST_10 Issue

## Problem Summary

**Test Failing:** TEST_10 (Tree)
**Error:** `Semantic Error: field left not found in class Tree`
**Root Cause:** Stub class with null dataMembers being used for field lookups instead of the completed class

## Analysis

### Issue #1: Stub Class Pattern
In [AstDecClass.java](src/ast/AstDecClass.java), the semantic analysis creates a "stub" TypeClass to handle self-referential fields (e.g., `Tree left` inside class `Tree`):

1. **Original approach:** Create stub with null dataMembers → Process members → Create NEW TypeClass → Add to symbol table to "shadow" stub
2. **Problem:** Field types resolved during member processing got references to the STUB (with null dataMembers), not the final class

### Issue #2: Symbol Table Scope Ordering
When processing `class Student extends Person`:
1. Father class scopes entered via `fatherClass.enterToSymbolTable()`
2. Stub entered AFTER father's beginScope()
3. Father scopes removed via `fatherClass.removeFromSymbolTable()`
4. **Result:** Student stub removed by father's endScope()!

## The Fix

### Fix Part 1: Update Stub In-Place
**File:** [AstDecClass.java:107](src/ast/AstDecClass.java#L107)

**Before:**
```java
TypeClass t = new TypeClass(fatherClass, name, dataMembers.semantMe(fatherClass));
// ...
SymbolTable.getInstance().enterWithoutCheck(name, t); // Try to shadow stub
```

**After:**
```java
TypeList members = dataMembers.semantMe(fatherClass);
stubType.dataMembers = members;  // Update stub in-place!
// No new TypeClass needed - stub is already in symbol table
```

**Why it works:** Any references to the stub (from self-referential fields) now see the complete class with all members.

### Fix Part 2: Enter Stub Before Father Scopes
**File:** [AstDecClass.java:88-95](src/ast/AstDecClass.java#L88-L95)

**Before:**
```java
if (baseClass != null) {
    // ... find father class ...
    fatherClass.enterToSymbolTable();  // Creates scope boundary
}
TypeClass stubType = new TypeClass(fatherClass, name, null);
SymbolTable.getInstance().enterWithoutCheck(name, stubType);  // AFTER father scope!
```

**After:**
```java
if (baseClass != null) {
    // ... find father class ...
    // DON'T call enterToSymbolTable() yet
}
TypeClass stubType = new TypeClass(fatherClass, name, null);
SymbolTable.getInstance().enterWithoutCheck(name, stubType);  // BEFORE father scopes

if (fatherClass != null) {
    fatherClass.enterToSymbolTable();  // Now enter father scopes
}
```

**Why it works:** Stub is entered BEFORE father's scope boundary, so `fatherClass.removeFromSymbolTable()` won't accidentally remove it.

## Impact

### Tests Fixed
- **TEST_10** - Tree (self-referential class fields) ✅
- Also maintained all 25 previously passing tests

### Final Results
- **26/26 tests passing (100%)**
- **Improvement from ex5:** +1 test (TEST_10)
- **Total improvement from initial state:** +11 tests (57.7% → 100%)

## Files Modified

1. **src/ast/AstDecClass.java**
   - Moved stub creation before father scope entry
   - Update stub in-place instead of creating new TypeClass
   - Removed redundant symbol table entry

2. **src/ast/AstDecClass.java** (helper method added)
   - Added `countMembers()` helper for debugging

## Technical Details

### Symbol Table Stack Behavior
The symbol table uses a stack structure where:
- `enterWithoutCheck(name, type)` pushes an entry onto the stack
- `beginScope()` pushes a SCOPE-BOUNDARY marker
- `endScope()` pops everything until it hits SCOPE-BOUNDARY, then pops the boundary itself

**Critical insight:** Anything entered AFTER a beginScope() will be removed by the corresponding endScope(), even if it's not logically "in" that scope.

### TypeClass Stub Pattern
The stub pattern is necessary for handling recursive type references:
```java
class Tree {
    Tree left := nil;   // "Tree" type must exist when processing this field
    Tree right := nil;
}
```

The stub allows "Tree" to be looked up while Tree is still being defined. The fix ensures the stub is completed before any code can observe its incomplete state.

## Testing

All 26 self-check tests now pass:
- Arrays: 4/4 ✅
- Strings: 1/1 ✅
- Classes: 4/4 ✅ (including inheritance)
- Control Flow: 6/6 ✅
- Arithmetic: 6/6 ✅
- Runtime Checks: 2/2 ✅
- Stress Tests: 2/2 ✅
- Tree structures: 1/1 ✅

## Difficulty Assessment

**Time to diagnose and fix:** ~45 minutes
**Complexity:** Medium
**Risk:** Low (only affects class declaration semantic analysis)

The fix was straightforward once the root cause was identified through systematic debugging with strategic print statements.

---

**Status:** ✅ COMPLETE
**Grade Impact:** 96.2% → 100% (A+ → A++)
