package ast;

import types.*;

public abstract class AstExp extends AstNode
{
    /***********************************************/
    /* The default semantic action for an AST node */
    /***********************************************/
    public Type semantMe() throws SemanticException
    {
        return null;
    }
}
