package types;

public class TypeForScopeBoundaries extends Type
{
	public TypeForScopeBoundaries(String name)
	{
		this.name = name;
	}
}
