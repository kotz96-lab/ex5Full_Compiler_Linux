package types;

public abstract class Type
{
	public String name;

	public boolean isClass(){ return false;}

	public boolean isArray(){ return false;}
}
